#' aGEw test
#'
#' @param Y  outcome of interest
#' @param G  genotype matrix
#' @param W  vector or weight matrix with each row as one set of weights
#' @param cov covariate matrix
#' @param model 'binomial' for binary outcome and 'gaussian' for continuous outcome
#' @param r1 Gamma set for r1, default is {1,2,3,4,5,6}
#' @param r2 Gamma set for r2, default is {1,2,4}
#' @param n.perm number of Monte Carlo simulations
#' @param nonparaE "T": use cubic splines for the environmental variable to fit the model; "F": use a linear function of the environmental variable to fit the model
#' @param DF degree of freedom to use in the cubic splines, default=10.
#' @param stepwise an option to speed up the simulation procedure for large n.perm number in real-data application. Up to $n.perm=10^8$

#' @return p-values
#' @export
#'
#' @examples {
#'  set.seed(12345)
#'  phenotype <- c(rep(1,50),rep(0,50))
#'  genotype <- data.frame(g1=sample(c(rep(1,10),rep(0,90))),g2=sample(c(rep(1,5), rep(0,95))))
#'  covariates <- data.frame(Envir=rnorm(100), Age=rnorm(100,60,5))
#'  exD <- list(Y=phenotype, G=genotype, X=covariates)
#'  weight <- c(1,1)
#'  aGEw(Y=exD$Y, G=exD$G, W=weight, cov=exD$X, model='binomial', r2=1)
#'  }
aGEw <- function(Y, G, W, cov = NULL, model = c("gaussian", "binomial"), r1 = c(1:6, Inf), r2=c(1,2,Inf), n.perm = 1000, nonparaE=F ,  DF=10,  stepwise=T){

  model = match.arg(model, c('gaussian','binomial'))
  Ind <- stats::complete.cases(Y) & stats::complete.cases(cov) & stats::complete.cases(G)
  Y <- Y[Ind]
  cov <- cov[Ind,]
  G<-as.matrix(G[Ind,])
  cov <- scale(cov,center=T, scale=T)
  G <- scale(G,center=T, scale=T)
  if (is.vector(W)) W <- as.matrix(t(W/sum(abs(W))))
  if (nrow(W) > 1 & ncol(W)> 1 ) W <- t(apply(W,1,function(x) x/sum(abs(x))))
  if (ncol(W) != ncol(G)) stop('Error:check the weight matrix!')
  E <- ME <- cov[,1]
  XUs <- E*G
  m <- nrow(W)
  q <- ncol(G)
  n <- length(Y)
  pis<-res<-tau<-phi<-WW<-NA

  if (nonparaE) {ME <- spl.X(x=E,df=DF); cov <- cbind(ME, cov[,-1])}

  nc <- ncol(cov)
  tdat1 <- data.frame(trait=Y,cov,G,id = rep(1, n))
  nullmodel <- GLMMaSPU(tdat1=tdat1,model=model,G=G, cov=cov, nc=nc, n=n)
  pis <- nullmodel$pis; tau<-nullmodel$tau; phi<-nullmodel$phi; WW<-nullmodel$W
  res <- as.vector(tdat1$trait - pis)
 
  Gw<-WW%*%G
  D <- solve( diag(1/tau, ncol(G)) + t(G) %*%  Gw )
  Vinv <- WW - Gw %*% D %*% t(Gw)

  Uobs <- as.vector(t(XUs) %*% res) /phi
  Uobs.w <- matrix(NA, nrow=m, ncol=q)
  for (i in 1:m) {
  Uobs.w[i,] <- W[i,] * Uobs
  }

  rm(i)

  #calculate Tobs
  Tobs.compute <- function(Us, r2=r2){
  Tobs<-matrix(NA, nrow=length(r1), ncol=length(r2) )
  for (i in 1:length(r1)) {
    for (j in 1:length(r2)){
	   if (r1[i] < Inf & r2[j] < Inf ){ Tobs[i,j] = round( sum(rowSums( as.matrix((Us)^r1[i])) ^ r2[j]), digits = 8) }
     if (r1[i] < Inf & r2[j] == Inf) {Tobs[i,j] = round( max(abs(rowSums( as.matrix((Us)^r1[i])))), digits = 8) }
     if (r1[i] == Inf & r2[j] < Inf) {Tobs[i,j] = round( sum( max(abs(Us)) ^ r2[j]), digits = 8) }
	   if (r1[i] == Inf & r2[j] == Inf) {Tobs[i,j] = round( max(abs(Us)), digits = 8) }
	}
	}
	return(Tobs)
}
  Tobs.w <- Tobs.compute(Us=Uobs.w, r2=r2)

  s <- sample(1:10^5,1)
  set.seed(s)
  if (stepwise){
  result <- RobustSim2(n=n, cov=cov, G=G, XUs=XUs, res=res, n.perm=1000, model=model , r1=r1, r2=r2, Tobs.w=Tobs.w,  W=W, Vinv=Vinv)

  if ((min(result$paGE,result$pfisher)<0.005) & (1000 < n.perm) )  result <- RobustSim2(n=n, cov=cov, G=G, XUs=XUs, res=res, n.perm=10000, model=model , r1=r1, r2=r2, Tobs.w=Tobs.w,  W=W, Vinv=Vinv)
  if ((min(result$paGE,result$pfisher)<0.0005) & (10000 < n.perm) )  result <- RobustSim2(n=n, cov=cov, G=G, XUs=XUs, res=res, n.perm=100000, model=model , r1=r1, r2=r2, Tobs.w=Tobs.w,  W=W, Vinv=Vinv)
  if ((min(result$paGE,result$pfisher)<0.00005) & (100000 < n.perm) )  result <- RobustSim2(n=n, cov=cov, G=G, XUs=XUs, res=res, n.perm=1000000, model=model , r1=r1, r2=r2, Tobs.w=Tobs.w,  W=W, Vinv=Vinv)
  if ((min(result$paGE,result$pfisher)<0.000005) & (1000000 < n.perm) )  result <- RobustSim2(n=n, cov=cov, G=G, XUs=XUs, res=res, n.perm=10000000, model=model , r1=r1, r2=r2, Tobs.w=Tobs.w,  W=W, Vinv=Vinv) 
  if ((min(result$paGE,result$pfisher)<0.000005) & (10000000 < n.perm) )  result <- RobustSim2(n=n, cov=cov, G=G, XUs=XUs, res=res, n.perm=100000000, model=model , r1=r1, r2=r2, Tobs.w=Tobs.w,  W=W, Vinv=Vinv)} else {
  result <- RobustSim2(n=n, cov=cov, G=G, XUs=XUs, res=res, n.perm=n.perm, model=model , r1=r1, r2=r2, Tobs.w=Tobs.w,  W=W, Vinv=Vinv)
  	
  }

  return(result)
}
